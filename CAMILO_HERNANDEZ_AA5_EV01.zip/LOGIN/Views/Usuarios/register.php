<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../../Css/register.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrarse</title>
</head>
<body>
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600' rel='stylesheet' type='text/css'>
<link href="//netdna.bootstrapcdn.com/font-awesome/3.1.1/css/font-awesome.css" rel="stylesheet">

<div class="testbox">
  <h1>Registrarse</h1>

  <form action="../../Models/registrar.php" method="post" enctype="multipart/form-data">
      <hr>
  <hr>
  <label id="icon" for="name"><i class="icon-user "></i></label>
  <input type="text" name="nombre_usuario" id="nombre_usuario" placeholder="Nombre de usuario" required/>
  <label id="icon" for="email"><i class="icon-envelope"></i></label>
  <input type="text" name="email" id="email" placeholder="Email" required/>
  <label id="icon" for="documento"><i class="icon-user"></i></label>
  <input type="text" name="documento" id="documento" placeholder="Documento" required/>
  <label id="icon" for="contraseña"><i class="icon-shield"></i></label>
  <input type="password" name="contraseña" id="contraseña" placeholder="Contraseña" required/>

   <p>Si ya completaste el formulario con los datos correspondientes presiona "Registrarse"</p>
   <button>Registrarse</button>
  </form>
</div>
</body>
</html>