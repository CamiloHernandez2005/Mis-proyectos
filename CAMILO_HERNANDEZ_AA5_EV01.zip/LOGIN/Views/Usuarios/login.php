<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../../Css/login.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio de sesión</title>
</head>
<body>
<div class="login-box">
  <h2>Ingresa sesión por favor</h2>
  <form action="../../Models/login.php" method="post">
    <div class="user-box">
      <input type="text" name="email" required="">
      <label>Correo</label>
    </div>
    <div class="user-box">
      <input type="password" name="contraseña" required="">
      <label>Contraseña</label>
    </div>
    
      <button>
      <a>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      Enviar
      </a>
</button>
    <a href="register.php">
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      Registrar
    </a>
  </form>
</div>
</body>
</html>
<?php
?>