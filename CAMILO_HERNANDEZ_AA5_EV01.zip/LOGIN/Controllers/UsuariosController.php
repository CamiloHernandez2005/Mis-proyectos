<?php
    include "../Config/Conexion.php";

    class Auth extends Conexion {
    
        public function registrar($nombre_usuario,$email,$documento, $contraseña) {
            $conexion = parent::conectar();
            $sql = "INSERT INTO usuarios (nombre_usuario, email, documento, contraseña)
                    VALUES (?,?,?,?)";
            $query = $conexion->prepare($sql);
            $query->bind_param('ssss', $nombre_usuario, $email, $documento, $contraseña);
            return $query->execute();
        }
        public function logear($email, $contraseña) {
            $conexion = parent::conectar();
            $passwordVer = "";
            $sql = "SELECT * FROM usuarios WHERE email = '$email'";
            $respuesta = mysqli_query($conexion, $sql);
            //
            if (mysqli_num_rows($respuesta) > 0) {
                $passwordVer = mysqli_fetch_array($respuesta);
                $passwordVer = $passwordVer['contraseña'];
                if (password_verify($contraseña, $passwordVer)) {
                    $_SESSION['email'] = $email;
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }   
    }

?>