<?php 
    session_start();
    include "../Controllers/UsuariosController.php";
    $email = $_POST['email'];
    $contraseña = $_POST['contraseña'];

    $Auth = new Auth();
    if ($Auth->logear($email, $contraseña)) {
        header("location:../index.php");
    } else {
        echo "
        <script>
        alert('No se encontro un perfil relacionado con estos datos, verifique');
        window.location.href='../Views/Usuarios/login.php';
        </script>";
    }
?>