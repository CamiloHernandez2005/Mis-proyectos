<?php
    include "../Controllers/UsuariosController.php";
    $nombre_usuario = $_POST['nombre_usuario'];
    $email = $_POST['email'];
    $documento = $_POST['documento'];
    $contraseña = password_hash($_POST['contraseña'], PASSWORD_DEFAULT);

    $Auth = new Auth();
    if ($Auth->registrar($nombre_usuario,$email,$documento, $contraseña)) {
        echo "
        <script>
        alert('Usuario registrado de manera exitosa!!!!');
        window.location.href='../Views/Usuarios/login.php';
        </script>";
    } else {
        echo "
        <script>
        alert('No se pudo registrar el usuario, verifique');
        window.location.href=''../Views/Usuarios/login.php';
        </script>";
    }
    
?>