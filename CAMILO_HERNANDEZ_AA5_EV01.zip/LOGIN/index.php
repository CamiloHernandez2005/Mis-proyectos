<h1>Bienvenido</h1>

<?php
//Se realiza esta validacion para que el usuario solo pueda
//acceder a traves del usuario y la password
//de otra manera lo redirijira al login
session_start();
if (!isset($_SESSION['email'])) {
  header("location:index.php");
}

?>

<ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
            <li><a href="Models/logout.php">Salir del sistema</a></li>
          </ul>